let r1 = 150;
let r2 = 150;
let r3 = 150;
let m1 = 10;
let m2 = 10;
let m3 = 10;
let a1, a2, a3;
let a1_v = 0;
let a2_v = 0;
let a3_v = 0;
let g = 1;
let px2, py2;
let cx, cy;
let buffer;
let slider1, slider2, slider3;
let lengthSlider1, lengthSlider2, lengthSlider3;
let startButton;
let started = false;

function setup() {
  createCanvas(800, 600);
  cx = width / 2;
  cy = 200;
  buffer = createGraphics(width, height);
  buffer.background(255);
  buffer.translate(cx, cy);

  // Create sliders for adjusting initial angles
  slider1 = createSlider(0, TWO_PI, PI / 2, 0.01);
  slider1.position(10, 10);
  slider2 = createSlider(0, TWO_PI, PI / 2, 0.01);
  slider2.position(10, 40);
  slider3 = createSlider(0, TWO_PI, PI / 2, 0.01);
  slider3.position(10, 70);

  // Create sliders for adjusting pendulum lengths
  lengthSlider1 = createSlider(50, 250, 150, 1);
  lengthSlider1.position(10, 100);
  lengthSlider2 = createSlider(50, 250, 150, 1);
  lengthSlider2.position(10, 130);
  lengthSlider3 = createSlider(50, 250, 150, 1);
  lengthSlider3.position(10, 160);

  // Create a button to start the simulation
  startButton = createButton('Start Simulation');
  startButton.position(10, 190);
  startButton.mousePressed(startSimulation);
}

function startSimulation() {
  a1 = slider1.value();
  a2 = slider2.value();
  a3 = slider3.value();
  r1 = lengthSlider1.value();
  r2 = lengthSlider2.value();
  r3 = lengthSlider3.value();
  a1_v = 0;
  a2_v = 0;
  a3_v = 0;
  buffer.background(255);
  started = true;
}

function draw() {
  background(255);
  image(buffer, 0, 0, width, height);
  translate(cx, cy);

  if (started) {
    let num1 = -g * (2 * m1 + m2 + m3) * sin(a1);
    let num2 = -m2 * g * sin(a1 - 2 * a2);
    let num3 = -2 * sin(a1 - a2) * m2;
    let num4 = a2_v * a2_v * r2 + a1_v * a1_v * r1 * cos(a1 - a2);
    let den = r1 * (2 * m1 + m2 - m2 * cos(2 * a1 - 2 * a2));
    let a1_a = (num1 + num2 + num3 * num4) / den;

    num1 = 2 * sin(a1 - a2);
    num2 = (a1_v * a1_v * r1 * (m1 + m2));
    num3 = g * (m1 + m2) * cos(a1);
    num4 = a2_v * a2_v * r2 * m2 * cos(a1 - a2);
    den = r2 * (2 * m1 + m2 - m2 * cos(2 * a1 - 2 * a2));
    let a2_a = (num1 * (num2 + num3 + num4)) / den;

    num1 = 2 * sin(a1 - a3);
    num2 = (a1_v * a1_v * r1 * (m1 + m3));
    num3 = g * (m1 + m3) * cos(a1);
    num4 = a3_v * a3_v * r3 * m3 * cos(a1 - a3);
    den = r3 * (2 * m1 + m3 - m3 * cos(2 * a1 - 2 * a3));
    let a3_a = (num1 * (num2 + num3 + num4)) / den;

    let x1 = r1 * sin(a1);
    let y1 = r1 * cos(a1);

    let x2 = x1 + r2 * sin(a2);
    let y2 = y1 + r2 * cos(a2);

    let x3 = x2 + r3 * sin(a3);
    let y3 = y2 + r3 * cos(a3);

    a1_v += a1_a;
    a2_v += a2_a;
    a3_v += a3_a;
    a1 += a1_v;
    a2 += a2_v;
    a3 += a3_v;

    stroke(0);
    strokeWeight(2);
    line(0, 0, x1, y1);
    fill(0);
    ellipse(x1, y1, m1, m1);

    line(x1, y1, x2, y2);
    fill(0);
    ellipse(x2, y2, m2, m2);

    line(x2, y2, x3, y3);
    fill(0);
    ellipse(x3, y3, m3, m3);

    buffer.stroke(0);
    if (frameCount > 1) {
      buffer.line(px2, py2, x3, y3);
    }

    px2 = x3;
    py2 = y3;
  }

  // Display slider labels
  fill(0);
  noStroke();
  text('Initial Angle 1', slider1.x * 2 + slider1.width, 15);
  text('Initial Angle 2', slider2.x * 2 + slider2.width, 45);
  text('Initial Angle 3', slider3.x * 2 + slider3.width, 75);
  text('Length 1', lengthSlider1.x * 2 + lengthSlider1.width, 105);
  text('Length 2', lengthSlider2.x * 2 + lengthSlider2.width, 135);
  text('Length 3', lengthSlider3.x * 2 + lengthSlider3.width, 165);
}